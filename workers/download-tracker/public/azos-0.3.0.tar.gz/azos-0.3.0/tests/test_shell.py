"""Ethics-coded remote shell: session, vfs, per-command gates."""

from __future__ import annotations

from pathlib import Path

import pytest

from azos.errors import AuthorizationError, HaltedError
from azos.ethics import SHELL_VERBS
from azos.gate import authorize_command, shell_proposal
from azos.runtime import Runtime
from tests.conftest import passing_proposal


def _open(runtime: Runtime, actor: str = "tester") -> tuple[str, str]:
    result = runtime.request(shell_proposal(actor))
    assert result.passed is True
    assert result.token
    opened = runtime.open_session(token=result.token, actor=actor)
    assert opened["session"]
    return result.token, opened["session"]


def test_session_requires_token(runtime: Runtime) -> None:
    with pytest.raises(AuthorizationError):
        runtime.open_session(actor="tester")


def test_shell_ls_and_write_and_cat(runtime: Runtime) -> None:
    token, session = _open(runtime)
    listed = runtime.run_command("ls", session_id=session, token=token)
    assert listed["ok"] is True
    assert listed["ethics"] is True
    assert "welcome.txt" in listed["stdout"]
    wrote = runtime.run_command(
        "write note.txt hello-ethics", session_id=session, token=token
    )
    assert wrote["ok"] is True
    cat = runtime.run_command("cat note.txt", session_id=session, token=token)
    assert cat["stdout"] == "hello-ethics"


def test_path_escape_denied(runtime: Runtime) -> None:
    token, session = _open(runtime)
    out = runtime.run_command("cat ../../etc/passwd", session_id=session, token=token)
    assert out["ok"] is False


def test_denied_verb_fails_integrity(runtime: Runtime) -> None:
    token, session = _open(runtime)
    out = runtime.run_command("bash -c id", session_id=session, token=token)
    assert out["ok"] is False
    assert out["ethics"] is False
    assert out["gates"]["integrity"]["pass"] is False
    assert out["invite"]


def test_host_meta_fails_impact(runtime: Runtime) -> None:
    token, session = _open(runtime)
    out = runtime.run_command("ls | cat", session_id=session, token=token)
    assert out["ok"] is False
    assert out["gates"]["impact"]["pass"] is False


def test_halt_then_command_fails(runtime: Runtime) -> None:
    token, session = _open(runtime)
    runtime.halt()
    with pytest.raises(HaltedError):
        runtime.run_command("ls", session_id=session, token=token)


def test_cli_shell_command(tmp_path: Path, monkeypatch, capsys) -> None:
    from azos.cli import main

    monkeypatch.chdir(tmp_path)
    rc = main(["shell", "--actor", "tester", "-c", "uname"])
    assert rc == 0
    assert "ethics-coded remote shell" in capsys.readouterr().out


def test_authorize_command_requires_actor_and_session() -> None:
    denied = authorize_command("ls", actor="", session_live=False)
    assert denied.passed is False
    ok = authorize_command("ls", actor="tester", session_live=True, allowed=SHELL_VERBS)
    assert ok.passed is True


def test_exec_shell_builtin_opens_and_runs(runtime: Runtime) -> None:
    result = runtime.request(passing_proposal("shell"))
    out = runtime.run(
        "shell",
        token=result.token,
        args={"command": "pwd", "actor": "tester"},
    )
    assert out["ok"] is True
    assert out["stdout"].strip() == "/"


def test_shell_status_and_session_are_sentences(runtime: Runtime) -> None:
    token, session = _open(runtime)
    status = runtime.run_command("status", session_id=session, token=token)
    assert status["ok"] is True
    assert "{" not in status["stdout"]
    assert "There is no kernel." in status["stdout"]
    assert "not a boot" in status["stdout"]
    assert "not this kernel and not this boot" in status["stdout"]
    assert "not joined and not live" in status["stdout"]
    record = status["status"]
    assert record["kernel"] is False
    assert record["kernel_base"] is False
    assert record["booted"] is False
    assert record["installed"] is False
    assert record["os_yet"] is False
    assert record["userspace_base"] is True
    assert record["internet_base"]["live"] is True
    assert record["internet_base"]["installed"] is False
    assert record["internet_base"]["base"] is True
    assert record["alt_internet_live"] is True
    assert record["packet_path_live"] is True
    assert "alt_internet_live is true" in status["stdout"]
    assert "packet_path_live is true" in status["stdout"]
    assert "Cap-7 and .aziel stay names" in status["stdout"]
    assert "A second device stays false" in status["stdout"]
    assert record["mail_send"] is False
    assert record["one_click_install_live"] is False
    assert record["mesh_node_live"] is True
    session_out = runtime.run_command("session", session_id=session, token=token)
    assert session_out["ok"] is True
    assert "{" not in session_out["stdout"]
    assert "not a boot" in session_out["stdout"]


def test_workspace_stays_under_session(runtime: Runtime, tmp_path: Path) -> None:
    token, session = _open(runtime)
    runtime.run_command("write a.txt x", session_id=session, token=token)
    workspace = tmp_path / ".azos" / "workspace" / session / "a.txt"
    assert workspace.is_file()
    assert workspace.read_text(encoding="utf-8") == "x"
    home_marker = Path.home() / "azos-should-not-exist-shell-test"
    assert not home_marker.exists()
