# AZ-OS

AZ-OS runs registered commands in a session folder on this machine, after an ethics check.

**Author:** Aziel Eliab  
**License:** [Apache-2.0](LICENSE)

## Start

1. Install (Python 3.10+):

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

2. Start the local app:

```bash
azos ui
```

3. Open http://127.0.0.1:8800/ and choose **Open shell**.

`azos doctor` checks this install. `azos --help` lists commands. Add `--json` when a program needs the machine record (`azos status --json`).

## One-click install

```bash
curl -fsSL https://azos-download-tracker.vibelock.workers.dev/install.sh | bash
azos ui
```

The script downloads the counted tarball (User-Agent `Mozilla/5.0`), extracts it, and installs. Then open http://127.0.0.1:8800/ and choose **Open shell**.

## Commands

Start here:

| Command | What it does |
|---|---|
| `azos` | Welcome and the next commands |
| `azos ui` | Local app at http://127.0.0.1:8800/ (this machine only) |
| `azos shell` | Session prompt. `azos shell -c 'ls'` runs one command |
| `azos status` | Ready or halted, watch, session folder |
| `azos doctor` | Local self-check |

Advanced (same command names as before):

| Command | What it does |
|---|---|
| `azos session --actor NAME` | Open a session and print its id |
| `azos exec NAME` | One registered builtin, with a live token |
| `azos halt` | Stop new commands. The watch stays on |
| `azos purge --confirm` | Delete the `.azos` folder in this directory |
| `azos invite` | Adoption text and download URL. Writes no files |
| `azos import FILE` | Read JSON into `.azos-state.json` |
| `azos export FILE` | Write `.azos-state.json` |
| `azos version` | Package version |
| `azos node` | Local AZnet hash client. Sidenet is AZnet |
| `azos news` | AZNews, alone or joined to the map. The news source is absent |
| `azos map` | Standalone 4DMap pins. 4DMap is not installed |

`azos node` keeps hash refs in `.azos/node/`. The text you pass to `stamp` is hashed and not stored. **AZ Browser** is the browser surface for AZnet. It is a separate product. This package does not include it. The AZ-OS layers stay `base`, `stacked`, and `standalone`.

| Layer | Need |
|---|---|
| `base` | Host OS stays the host OS. AZ-OS stays an overlay. Local garden. |
| `stacked` | Same local garden. FragGate HTTPS stays the online door. |
| `standalone` | Same local garden. No shell session. Softwares desk unchanged. |

These names are overlay modes. The command does not install or replace an operating system. `azos node probe` is the only node command that uses the network: it sends `GET /v1/health` and does not call a FragGate op. Online calls still go through `https://aziel-runtime.vibelock.workers.dev/v1/fraggate/call`. The Softwares desk is unchanged.

`--json` on `status`, `doctor`, `session`, `exec`, `halt`, `purge`, `import`, `export`, `node`, `news`, and `map` prints the machine record. `azos --json` prints status.

Builtins for `azos exec`: `list_modules`, `echo`, `status`, `purge_session`, `shell`.

Shell commands: `help`, `pwd`, `ls`, `cat`, `write`, `echo`, `mkdir`, `rm`, `cd`, `status`, `principles`, `invite`, `modules`, `history`, `whoami`, `session`, `halt`, `exit`, `id`, `uname`.

## Local app

`azos ui` prints `Open http://127.0.0.1:8800/` and serves AZ Interface on that address.

The first screen has one primary action, **Open shell**. Help sits beside it. Under that, **News and the map** explains the joined path and the two standalone paths. AZNews can stand alone. 4DMap can stand alone. On the joined path, a news item can become a map pin (date, event, and place), or a pin can open the matching news. That join points at the runtime 4DMap engine. This package does not claim the aziel-runtime side is done. AZ-OS does not install 4DMap and does not keep a second map. `azos.news_source` can GET a standing feed. That feed has no score and no place, so the news source stays absent and AZNews and 4DMap stay not joined. Pin and open refuse instead of inventing them. Nothing on that join is marked live or merged until a fetched item lands as a map pin. Halt, purge, the ethics form, catalog hooks, the lattice, and the log are under **Advanced**. Light and dark follow the system. Keyboard focus uses a gold ring. The layout fits a narrow phone width.

A program can send `Accept: application/json` on `GET /` for the status record. `GET /api/node` reports the local AZnet client. The Softwares desk on the page is unchanged.

## Notes

Integrity precedes execution.

This package is a prefab of catalog hooks, including TemporalLock timeslates chained to StaticClock. The local program is the ethics-gated remote shell. There is no kernel in this repository, and there is no malware routine. The userspace base is present. That is a base, not a boot. A process receipt, a loopback bind, and a userspace file are not a host kernel. AZ Interface is a separate shell. It is not this kernel and not this boot.

| Layer | What it does |
|---|---|
| Protocols | HTTPS JSON on the Worker, HTTP on `127.0.0.1:8800`, and CLI stdin (`azos shell`). `azos node probe` may GET FragGate health. Other node commands stay on disk. |
| Auth | A token is issued only after five checks pass: definition, evidence, impact, integrity, responsibility. The token is hashed at rest. A name is not a privilege. |
| Sandbox | Session folder: local `.azos/workspace/<id>/`. Closed command list. |
| Halt | Stops new commands. The watch (Lumen) stays on and can still revoke a token or purge `.azos`. |
| Purge | Deletes the `.azos` folder in this directory only. |

Principles, as enforced in code:

1. Integrity precedes execution.
2. Time-bound actions are final.
3. Understanding precedes modification.
4. The system protects itself architecturally.
5. Propagation is not infection.

`azos invite` prints those principles and a download URL. It does not copy this program onto another machine.

Session state lives in `.azos/` (hashed tokens, log, halt flag, workspace).

Counted download: https://azos-download-tracker.vibelock.workers.dev/

- Tarball: https://azos-download-tracker.vibelock.workers.dev/download?asset=azos-0.3.0.tar.gz
- Install script: https://azos-download-tracker.vibelock.workers.dev/install.sh
- OpenAPI: https://azos-download-tracker.vibelock.workers.dev/openapi.json
- GitHub: https://github.com/AzielEliab/azos

No Zenodo DOI is claimed. `/v1` on the Worker does not increment downloads.

Suite mesh: https://azos-download-tracker.vibelock.workers.dev/v1/mesh — read-only proxy, default off. QNS-CD-1.0 is a cite. GET does not enable it.

Papers: [docs/whitepaper.md](docs/whitepaper.md). Contributing: [CONTRIBUTING.md](CONTRIBUTING.md).

### Programs

Import `https://azos-download-tracker.vibelock.workers.dev/openapi.json`. Health: `GET /v1/health`. Local status for a program: `azos status --json`.

```bash
curl -sS -A 'Mozilla/5.0' -X POST https://azos-download-tracker.vibelock.workers.dev/v1/session \
  -H 'content-type: application/json' \
  -d '{"actor":"operator","definition":"Open an ethics-gated shell session.","evidence":"Operator requested a principle-bound remote shell.","impact":"Hosted KV vfs only. No host subprocess."}'
```

### Phone sources

Flutter sources are in [`mobile/`](mobile/). Application id `com.azieeliab.azos`. The `android/` and `ios/` folders are skeleton notes until `flutter create .` is run.

### Tests

```bash
pip install -e ".[dev]"
python -m pytest -q
```

### Layout

```
azos/               library and local app (azos/node.py is the AZnet client)
tests/              pytest
docs/whitepaper.md  papers
mobile/             Flutter sources
workers/download-tracker/   counted download Worker
```
