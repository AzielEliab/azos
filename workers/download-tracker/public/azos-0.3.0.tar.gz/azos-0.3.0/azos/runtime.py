"""Composition root: ARC + Lumen + gate + exec + log + ethics-coded shell."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from azos.arc import ARC
from azos.errors import AuthorizationError
from azos.ethics import KIND, scope_dict
from azos.exec import SAFE_ACTIONS, Executor
from azos.gate import Proposal, authorize
from azos.invite import invite_text
from azos.lattice import IntegrityLattice
from azos.log import ExecutionLog
from azos.lumen import Lumen
from azos.paths import SESSION_DIRNAME
from azos.prefab import prefab_snapshot
from azos.shell import Shell

__all__ = ["Runtime", "RequestResult", "SAFE_ACTIONS"]


@dataclass
class RequestResult:
    passed: bool
    token: str | None
    gates: dict[str, Any]
    invite: str | None

    def as_dict(self) -> dict[str, Any]:
        preview = None
        if self.token:
            preview = self.token[:8] + "…"
        return {
            "passed": self.passed,
            "token": self.token,
            "token_preview": preview,
            "gates": self.gates,
            "invite": self.invite,
        }


class Runtime:
    """One overlay session rooted at ``<root>/.azos``."""

    def __init__(
        self,
        root: Path | str | None = None,
        *,
        start_lumen: bool = True,
    ) -> None:
        self.root = Path(root) if root is not None else Path.cwd()
        self.session_dir = self.root / SESSION_DIRNAME
        self.arc = ARC(self.session_dir)
        self.log = ExecutionLog(self.session_dir / "exec.jsonl")
        self._halted = False
        self._load_state()
        self.lattice = IntegrityLattice(self.session_dir)
        self.lumen = Lumen(self)
        self.executor = Executor(self)
        self.shell = Shell(self)
        if start_lumen:
            self.lumen.start()

    @property
    def halted(self) -> bool:
        return self._halted

    def mark_halted(self, value: bool = True) -> None:
        self._halted = bool(value)
        self._save_state()

    def request(self, proposal: Proposal) -> RequestResult:
        """Five gates then (only on PASS) an ARC token. FAIL → invite, no token."""
        if self._halted:
            return RequestResult(
                passed=False,
                token=None,
                gates={
                    "definition": {"pass": False, "reason": "overlay is halted"},
                    "evidence": {"pass": False, "reason": "overlay is halted"},
                    "impact": {"pass": False, "reason": "overlay is halted"},
                    "integrity": {"pass": False, "reason": "overlay is halted"},
                    "responsibility": {"pass": False, "reason": "overlay is halted"},
                },
                invite=invite_text(),
            )
        return self._issue(proposal, SAFE_ACTIONS)

    def request_node(self, proposal: Proposal) -> RequestResult:
        """Five gates for a local AZnet hash write. Does not call FragGate."""
        from azos.node import NODE_ACTIONS

        return self._issue(proposal, NODE_ACTIONS)

    def _issue(self, proposal: Proposal, allowed: frozenset[str]) -> RequestResult:
        if self._halted:
            return RequestResult(
                passed=False,
                token=None,
                gates={
                    "definition": {"pass": False, "reason": "overlay is halted"},
                    "evidence": {"pass": False, "reason": "overlay is halted"},
                    "impact": {"pass": False, "reason": "overlay is halted"},
                    "integrity": {"pass": False, "reason": "overlay is halted"},
                    "responsibility": {"pass": False, "reason": "overlay is halted"},
                },
                invite=invite_text(),
            )
        result = authorize(proposal, allowed)
        gates = {
            name: {"pass": check.passed, "reason": check.reason}
            for name, check in result.gates.items()
        }
        if not result.passed:
            return RequestResult(
                passed=False,
                token=None,
                gates=gates,
                invite=invite_text(),
            )
        token = self.arc.issue(action=proposal.action, actor=proposal.actor)
        self.lattice.bind(
            f"request:{proposal.action}",
            summary=f"ARC token issued for {proposal.action}",
            evidence="five ethics gates passed",
        )
        return RequestResult(passed=True, token=token, gates=gates, invite=None)

    def run(
        self,
        name: str,
        token: str | None = None,
        args: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.executor.run(name, token=token, args=args)

    def open_session(self, *, token: str | None = None, actor: str = "") -> dict[str, Any]:
        opened = self.shell.open(token=token, actor=actor)
        opened["lattice"] = self.lattice.bind(
            "session:open",
            summary="ethics-gated shell session opened",
            evidence=f"actor {actor or 'operator'}",
        )
        return opened

    def run_command(
        self,
        command: str,
        *,
        session_id: str,
        token: str | None = None,
    ) -> dict[str, Any]:
        if not self.lattice.verify():
            raise AuthorizationError("integrity: TemporalLock×StaticClock lattice failed")
        out = self.shell.execute(command, session_id=session_id, token=token)
        if out.get("ok"):
            out["lattice"] = self.lattice.bind(
                f"shell:{(command or 'cmd').split()[0][:32]}",
                summary="principle-bound command",
                evidence="ethics gates passed",
            )
        return out

    def status(self) -> dict[str, Any]:
        arc = self.arc.snapshot()
        scope = scope_dict()
        return {
            "overlay": "AZ-OS",
            "interface": "AZ Interface",
            "kind": KIND,
            "version": _version(),
            "session": str(self.session_dir),
            "halted": self._halted,
            "lumen": "running" if self.lumen.running else "stopped",
            "tokens": arc,
            "log_length": len(self.log),
            "builtins": sorted(SAFE_ACTIONS),
            "shell": self.shell.snapshot(),
            "offline_node": _offline_node_summary(self.root),
            "news_map": _news_map_summary(self.root),
            **scope,
            "prefab": prefab_snapshot(),
            "lattice": self.lattice.snapshot(),
        }

    def halt(self) -> dict[str, Any]:
        out = self.lumen.halt()
        out["lattice"] = self.lattice.bind(
            "halt",
            summary="execution authority halted",
            evidence="Lumen keeps custody",
        )
        return out

    def purge(self, *, confirm: bool) -> dict[str, Any]:
        return self.lumen.purge_session(confirm=confirm)

    def _state_path(self) -> Path:
        return self.session_dir / "state.json"

    def _load_state(self) -> None:
        path = self._state_path()
        if not path.is_file():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if isinstance(data, dict):
            self._halted = bool(data.get("halted"))

    def _save_state(self) -> None:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        payload = {"halted": self._halted, "lumen": "running"}
        self._state_path().write_text(
            json.dumps(payload, indent=2) + "\n", encoding="utf-8"
        )


def _version() -> str:
    from azos import __version__

    return __version__


def _news_map_summary(root: Path) -> dict[str, Any]:
    """Read-only pointer at the runtime AZNews ↔ 4DMap join. Writes nothing."""
    from azos.newsmap import NewsMap

    record = NewsMap(root=root).status()
    live = (
        record.get("live") is True
        and record.get("source_present") is True
        and record.get("refused") is not True
        and record.get("item_landed") is True
        and record.get("code") != "AZNEWS-SOURCE-ABSENT"
    )
    paths = dict(record.get("paths") or {})
    joined = dict(paths.get("joined") or {})
    joined["live"] = live
    paths["joined"] = joined
    return {
        "join": record["join"],
        "engine_slug": record["engine_slug"],
        "engine_name": record["engine_name"],
        "installed": False,
        "engine_installed": False,
        "second_app": False,
        "engine_copy": False,
        "source": record["source"],
        "source_present": live,
        "absent": record["absent"],
        "code": record["code"],
        "merged": False,
        "live": live,
        "lattice_live": False,
        "door": record["door"],
        "pin_op": record["pin_op"],
        "open_op": record["open_op"],
        "plain": record["plain"],
        "item_landed": live,
        "author": record["author"],
        "paths": paths,
        "runtime_done": False,
        "runtime_claimed": False,
        "cross_tether": True,
        "not_live": record.get("not_live"),
    }


def _offline_node_summary(root: Path) -> dict[str, Any]:
    """Read-only AZnet client summary. Does not create the node folder."""
    from azos.node import OfflineNode

    record = OfflineNode(root=root).status()
    return {
        "client": record["client"],
        "sidenet": record["sidenet"],
        "sidenet_is_aznet": True,
        "browser_surface": record["browser_surface"],
        "browser_role": record["browser_role"],
        "browser_in_this_package": False,
        "layers_additive": True,
        "layer": record["layer"],
        "layers": record["layers"],
        "l0_executed": False,
        "l0_replaced": False,
        "softwares_desk": "frozen",
        "payload_host": False,
        "garden_count": record["garden_count"],
        "hosted_engine": False,
    }
