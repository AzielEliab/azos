"""Self-check for AZ-OS. No network, no telemetry.

    azos doctor
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Callable

from azos import __version__

AUTHOR = "Aziel Eliab"
Check = tuple[str, bool, str]


def _ok(name: str, detail: str = "") -> Check:
    return name, True, detail


def _fail(name: str, detail: str) -> Check:
    return name, False, detail


def _check_version() -> Check:
    if __version__:
        return _ok("version", str(__version__))
    return _fail("version", "missing")


def _check_identity() -> Check:
    try:
        mod = __import__(__name__.split(".")[0])
        author = str(getattr(mod, "__author__", AUTHOR))
    except Exception as exc:  # noqa: BLE001
        return _fail("identity", str(exc))
    blob = author + " " + AUTHOR
    forbidden = ("Col" + "lin H" + "orton", "Ja" + "ck Al" + "tman", "GodLock" + ".AZ", "Reve" + "aler")
    if any(x in blob for x in forbidden):
        return _fail("identity", "forbidden identity label")
    if "Aziel Eliab" not in blob:
        return _fail("identity", author)
    return _ok("identity", AUTHOR)



def _check_prefab_lattice() -> Check:
    try:
        from azos.lattice import IntegrityLattice
        from azos.prefab import prefab_apps
    except Exception as exc:  # noqa: BLE001
        return _fail("prefab-lattice", str(exc))
    if len(prefab_apps()) < 25:
        return _fail("prefab-lattice", "catalog short")
    lat = IntegrityLattice()
    lat.bind("doctor", summary="self-check", evidence="doctor")
    if not lat.verify():
        return _fail("prefab-lattice", "lattice verify")
    return _ok("prefab-lattice", f"{len(prefab_apps())} apps")


def _check_ethics_shell() -> Check:
    try:
        from azos.ethics import KIND, SHELL_VERBS, scope_dict
        from azos.shell import Shell
    except Exception as exc:  # noqa: BLE001
        return _fail("ethics-shell", str(exc))
    if KIND != "ethics_coded_remote_shell":
        return _fail("ethics-shell", KIND)
    if "ls" not in SHELL_VERBS or "bash" in SHELL_VERBS:
        return _fail("ethics-shell", "verb list")
    scope = scope_dict()
    if scope.get("host_subprocess") is not False:
        return _fail("ethics-shell", "host subprocess must be false")
    if not getattr(Shell, "execute", None):
        return _fail("ethics-shell", "Shell.execute missing")
    return _ok("ethics-shell", KIND)


def _check_json_roundtrip() -> Check:
    from azos.jsonio import export_json, import_json

    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "in.json"
        out = Path(tmp) / "out.json"
        src.write_text(json.dumps({"product": "azos", "author": AUTHOR, "ok": True}, indent=2), encoding="utf-8")
        rec = import_json(src)
        if not rec.get("ok"):
            return _fail("import", str(rec))
        rec2 = export_json(out)
        if not rec2.get("ok") or not out.exists():
            return _fail("export", str(rec2))
        doc = json.loads(out.read_text(encoding="utf-8"))
        if doc.get("author") != AUTHOR:
            return _fail("export author", str(doc.get("author")))
        return _ok("json import/export", "roundtrip")


CHECKS: tuple[Callable[[], Check], ...] = (
    _check_version,
    _check_identity,
    _check_ethics_shell,
    _check_prefab_lattice,
    _check_json_roundtrip,
)


def run_doctor(*, as_json: bool = False) -> int:
    results = []
    failed = 0
    for fn in CHECKS:
        name, ok, detail = fn()
        results.append({"name": name, "ok": ok, "detail": detail})
        if not ok:
            failed += 1
        mark = "ok" if ok else "FAIL"
        if not as_json:
            print(f"[{mark}] {name}" + (f" — {detail}" if detail else ""))
    payload = {
        "ok": failed == 0,
        "failed": failed,
        "checks": results,
        "version": __version__,
        "author": AUTHOR,
        "kind": "ethics_coded_remote_shell",
        "network": False,
        "telemetry": False,
    }
    if as_json:
        print(json.dumps(payload, indent=2))
    else:
        print("doctor", "passed" if failed == 0 else "failed")
    return 0 if failed == 0 else 1
