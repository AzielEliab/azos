"""Self-check for AZ-OS. No telemetry.

The door check reads the same refusals the runtime publishes.
It does not treat a receipt, a loopback bind, or a userspace file as a kernel.

    azos doctor
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Callable

from azos import __version__

AUTHOR = "Aziel Eliab"
Check = tuple[str, bool, str]


def _ok(name: str, detail: str = "") -> Check:
    return name, True, detail


def _fail(name: str, detail: str) -> Check:
    return name, False, detail


def _check_version() -> Check:
    if __version__:
        return _ok("version", str(__version__))
    return _fail("version", "missing")


def _check_identity() -> Check:
    try:
        mod = __import__(__name__.split(".")[0])
        author = str(getattr(mod, "__author__", AUTHOR))
    except Exception as exc:  # noqa: BLE001
        return _fail("identity", str(exc))
    blob = author + " " + AUTHOR
    forbidden = ("Col" + "lin H" + "orton", "Ja" + "ck Al" + "tman", "GodLock" + ".AZ", "Reve" + "aler")
    if any(x in blob for x in forbidden):
        return _fail("identity", "forbidden identity label")
    if "Aziel Eliab" not in blob:
        return _fail("identity", author)
    return _ok("identity", AUTHOR)



def _check_prefab_lattice() -> Check:
    try:
        from azos.lattice import IntegrityLattice
        from azos.prefab import prefab_apps
    except Exception as exc:  # noqa: BLE001
        return _fail("prefab-lattice", str(exc))
    if len(prefab_apps()) < 25:
        return _fail("prefab-lattice", "catalog short")
    lat = IntegrityLattice()
    lat.bind("doctor", summary="self-check", evidence="doctor")
    if not lat.verify():
        return _fail("prefab-lattice", "lattice verify")
    return _ok("prefab-lattice", f"{len(prefab_apps())} apps")


def _check_ethics_shell() -> Check:
    try:
        from azos.ethics import KIND, SHELL_VERBS, scope_dict
        from azos.shell import Shell
    except Exception as exc:  # noqa: BLE001
        return _fail("ethics-shell", str(exc))
    if KIND != "ethics_coded_remote_shell":
        return _fail("ethics-shell", KIND)
    if "ls" not in SHELL_VERBS or "bash" in SHELL_VERBS:
        return _fail("ethics-shell", "verb list")
    scope = scope_dict()
    if scope.get("host_subprocess") is not False:
        return _fail("ethics-shell", "host subprocess must be false")
    if not getattr(Shell, "execute", None):
        return _fail("ethics-shell", "Shell.execute missing")
    return _ok("ethics-shell", KIND)


def _check_sidenet() -> Check:
    from azos.sidenet import OfflineNode, SidenetRefuse

    try:
        with tempfile.TemporaryDirectory() as tmp:
            node = OfflineNode(tmp)
            menu = node.menu()
    except Exception as exc:  # noqa: BLE001
        return _fail("sidenet", str(exc))
    if menu.get("layer") != "stacked-os":
        return _fail("sidenet", "layer")
    if menu.get("icann_tld_az") is not False or menu.get("radio_phy") is not False:
        return _fail("sidenet", "icann or radio painted live")
    if menu.get("softwares_cards"):
        return _fail("sidenet", "invented softwares cards")
    items = {item["id"]: item for item in menu.get("items") or [] if isinstance(item, dict)}
    for slot_id in ("plane-b", "plane-c", "live-node-api", "doi"):
        if items.get(slot_id, {}).get("status") != "SLOT":
            return _fail("sidenet", slot_id)
    cap7 = items.get("cap7-factory-cite", {})
    if cap7.get("internet_reachable") is not False or cap7.get("icann_tld_az") is not False:
        return _fail("sidenet", "cap7")
    if items.get("radio-phy", {}).get("status") == "LIVE":
        return _fail("sidenet", "radio phy")
    auto = items.get("auto-update", {})
    if auto.get("status") == "LIVE" or auto.get("live") is True or auto.get("radio_phy") is True:
        return _fail("sidenet", "auto-update")
    if auto.get("satellite_relay") != "HELD" or auto.get("second_device") is True:
        return _fail("sidenet", "satellite")
    if items.get("softwares-desk", {}).get("status") != "FROZEN":
        return _fail("sidenet", "softwares desk")
    home = node.dir
    if home.name != "sidenet-p4" or home.parent.name != "node":
        return _fail("sidenet", "path")
    try:
        node.reheal(vote=True)
    except SidenetRefuse as exc:
        if exc.code != "SIDENET-NO-VOTE":
            return _fail("sidenet", exc.code)
    else:
        return _fail("sidenet", "vote was accepted")
    return _ok("sidenet", "stacked offline node")


def _check_json_roundtrip() -> Check:
    from azos.jsonio import export_json, import_json

    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "in.json"
        out = Path(tmp) / "out.json"
        src.write_text(json.dumps({"product": "azos", "author": AUTHOR, "ok": True}, indent=2), encoding="utf-8")
        rec = import_json(src)
        if not rec.get("ok"):
            return _fail("import", str(rec))
        rec2 = export_json(out)
        if not rec2.get("ok") or not out.exists():
            return _fail("export", str(rec2))
        doc = json.loads(out.read_text(encoding="utf-8"))
        if doc.get("author") != AUTHOR:
            return _fail("export author", str(doc.get("author")))
        return _ok("json import/export", "roundtrip")


def _check_offline_node() -> Check:
    try:
        from azos.node import LAYERS, L0_DOOR, OfflineNode
        from azos.prefab import slugs
    except Exception as exc:  # noqa: BLE001
        return _fail("offline-node", str(exc))
    if tuple(LAYERS) != ("base", "stacked", "standalone"):
        return _fail("offline-node", "layers")
    with tempfile.TemporaryDirectory() as tmp:
        record = OfflineNode(root=tmp).status()
    if record.get("sidenet") != "aznet" or record.get("sidenet_is_aznet") is not True:
        return _fail("offline-node", "sidenet")
    if record.get("browser_surface") != "AZ Browser" or record.get("browser_role") != "browser surface for AZnet":
        return _fail("offline-node", "browser surface")
    if record.get("browser_is_layer") is not False or record.get("layers_additive") is not True:
        return _fail("offline-node", "layers")
    if record.get("browser_in_this_package") is not False or "azbrowser" in slugs():
        return _fail("offline-node", "browser package")
    if record.get("l0_executed") is not False or record.get("l0_replaced") is not False:
        return _fail("offline-node", "l0")
    if record.get("payload_host") is not False or record.get("softwares_desk") != "frozen":
        return _fail("offline-node", "desk")
    if "azos-node" in slugs() or L0_DOOR.endswith("/v1/fraggate/call") is False:
        return _fail("offline-node", "prefab")
    return _ok("offline-node", "aznet client")


def _check_news_map() -> Check:
    try:
        from azos.newsmap import ABSENT_MODULE, ENGINE_SLUG, NewsMap
        from azos.prefab import prefab_apps, slugs
    except Exception as exc:  # noqa: BLE001
        return _fail("news-map", str(exc))
    if "4dmap" in slugs() or "aznews" in slugs():
        return _fail("news-map", "prefab slug")
    for app in prefab_apps():
        if app.get("slug") in {"4dmap", "aznews"} and app.get("installed"):
            return _fail("news-map", "installed")
    with tempfile.TemporaryDirectory() as tmp:
        record = NewsMap(root=tmp).status()
    if record.get("installed") or record.get("engine_installed") or record.get("source_present"):
        return _fail("news-map", "flags")
    if record.get("live") or record.get("merged") or record.get("lattice_live"):
        return _fail("news-map", "live")
    if record.get("engine_slug") != ENGINE_SLUG or record.get("absent") != ABSENT_MODULE:
        return _fail("news-map", "door")
    if record.get("engine_copy") or record.get("second_app"):
        return _fail("news-map", "copy")
    if record.get("runtime_done") is not False or record.get("cross_tether") is not True:
        return _fail("news-map", "runtime")
    paths = record.get("paths") if isinstance(record.get("paths"), dict) else {}
    if not paths.get("joined") or not paths.get("aznews_standalone") or not paths.get("fourdmap_standalone"):
        return _fail("news-map", "paths")
    not_live = record.get("not_live") if isinstance(record.get("not_live"), dict) else {}
    for key in ("internet", "mail", "kernel", "one_click_install", "mesh_node"):
        if not_live.get(key) is not False:
            return _fail("news-map", key)
    return _ok("news-map", "runtime join, source absent")


def _check_doors() -> Check:
    try:
        from azos.doors import prove, scope_follows
    except Exception as exc:  # noqa: BLE001
        return _fail("doors", str(exc))
    with tempfile.TemporaryDirectory() as tmp:
        try:
            proof = prove(Path(tmp))
            scope_follows(proof)
        except Exception as exc:  # noqa: BLE001
            return _fail("doors", str(exc))
    flags = proof["flags"]
    if flags.get("userspace_base") is not True:
        return _fail("doors", "userspace")
    if proof["doors"]["userspace_base"].get("booted") is True:
        return _fail("doors", "booted")
    for name in ("kernel", "booted", "installed", "mail_send", "one_click_install_live"):
        if flags.get(name) is not False:
            return _fail("doors", name)
        if proof["doors"][name].get("refused") is not True:
            return _fail("doors", name)
    if flags.get("internet") is not True or proof["doors"]["internet"].get("refused") is True:
        return _fail("doors", "internet")
    if flags.get("mesh_node_live") is not True or proof["doors"]["mesh_node_live"].get("live") is not True:
        return _fail("doors", "mesh_node_live")
    if proof["doors"]["mesh_node_live"].get("code") != "MESH-NODE-LIVE":
        return _fail("doors", "mesh_node_live")
    if flags.get("join_live") is True:
        return _fail("doors", "join")
    if proof["doors"]["join_live"].get("code") != "AZNEWS-SOURCE-ABSENT":
        return _fail("doors", "join")
    if proof["doors"]["kernel"].get("host_kernel") is True or proof["doors"]["kernel"].get("kernel_base") is True:
        return _fail("doors", "host kernel")
    if proof["doors"]["mail_send"].get("public_mta") is True or proof["doors"]["mail_send"].get("sent") is True:
        return _fail("doors", "public mail")
    if proof["doors"]["mesh_node_live"].get("public_bind") is True:
        return _fail("doors", "public bind")
    if proof["doors"]["installed"].get("fourdmap_installed") is True:
        return _fail("doors", "4dmap")
    if proof["doors"]["booted"].get("booted") is True:
        return _fail("doors", "booted")
    internet = proof["doors"]["internet"]
    plain = str(internet.get("plain") or "")
    if internet.get("packet_path_live") is not True or internet.get("alt_internet_live") is not True:
        return _fail("doors", "internet")
    if internet.get("live") is not True:
        return _fail("doors", "internet")
    if internet.get("foreign_arrival") is True or internet.get("second_device") is True:
        return _fail("doors", "internet")
    if internet.get("cap7_public_egress") is True or internet.get("public_icann") is True or internet.get("bgp") is True:
        return _fail("doors", "cap7")
    if "alt_internet_live is true" not in plain or "packet_path_live is true" not in plain:
        return _fail("doors", "internet sentence")
    if "Cap-7 and .aziel stay names" not in plain or "A second device stays false" not in plain:
        return _fail("doors", "internet sentence")
    if "A same-machine mesh frame does not count." not in plain:
        return _fail("doors", "internet sentence")
    from azos.carriers import host_hardware_visible

    if host_hardware_visible():
        if "cannot see host hardware" in plain:
            return _fail("doors", "internet sentence")
    elif "This isolate cannot see host hardware (worker_hardware is false)." not in plain:
        return _fail("doors", "internet sentence")
    elif "QNM-RADIO-ABSENT" in plain:
        return _fail("doors", "invented radio")
    return _ok("doors", "userspace base, not a boot")


def _check_update() -> Check:
    from azos.update_apply import boot_update

    try:
        with tempfile.TemporaryDirectory() as tmp:
            result = boot_update(tmp)
    except Exception as exc:  # noqa: BLE001
        return _fail("update", str(exc))
    if result.get("code") != "UPDATE-OFF":
        return _fail("update", str(result.get("code")))
    if result.get("live") is True or result.get("applied") is True or result.get("booted") is True:
        return _fail("update", "flags")
    if result.get("os_yet") is True or result.get("installed") is True or result.get("one_click_install_live") is True:
        return _fail("update", "install")
    if result.get("radio_phy") is True or result.get("second_device") is True or result.get("satellite_relay") != "HELD":
        return _fail("update", "carrier")
    need = result.get("need") if isinstance(result.get("need"), list) else []
    if not any("trust.json" in str(item) for item in need):
        return _fail("update", "need")
    return _ok("update", "signed update off until trust is configured")


CHECKS: tuple[Callable[[], Check], ...] = (
    _check_version,
    _check_identity,
    _check_ethics_shell,
    _check_prefab_lattice,
    _check_json_roundtrip,
    _check_offline_node,
    _check_sidenet,
    _check_news_map,
    _check_doors,
    _check_update,
)


def run_doctor(*, as_json: bool = False) -> int:
    results = []
    failed = 0
    for fn in CHECKS:
        name, ok, detail = fn()
        results.append({"name": name, "ok": ok, "detail": detail})
        if not ok:
            failed += 1
        mark = "ok" if ok else "FAIL"
        if not as_json:
            print(f"[{mark}] {name}" + (f" — {detail}" if detail else ""))
    payload = {
        "ok": failed == 0,
        "failed": failed,
        "checks": results,
        "version": __version__,
        "author": AUTHOR,
        "kind": "ethics_coded_remote_shell",
        "network": False,
        "telemetry": False,
    }
    if as_json:
        print(json.dumps(payload, indent=2))
    else:
        print("doctor", "passed" if failed == 0 else "failed")
        if failed == 0:
            print("Next: azos ui")
        else:
            print("Next: azos doctor --json")
    return 0 if failed == 0 else 1
